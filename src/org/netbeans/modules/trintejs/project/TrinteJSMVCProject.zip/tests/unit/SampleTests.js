/**
 * Dependencies
 */
var     should = require('should');

/**
 * Simple expresso tests
 */
module.exports = {
		    
  'Placeholder for a real unit test': function(){	    
	    true.should.be.true;    
   }

};