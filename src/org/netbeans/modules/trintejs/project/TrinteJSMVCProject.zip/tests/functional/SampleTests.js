/**
 * Dependencies
 */
var     should = require('should');

/**
 * Simple expresso tests for the Example model
 */
module.exports = {
		    
  'Placeholder for a real functional test': function(){	    
	    true.should.be.true;    
   }

};