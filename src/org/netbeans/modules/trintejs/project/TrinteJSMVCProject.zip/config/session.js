/**
 *  Default session manager
 *  Inject app and express reference
 *
 *  Created by init script
 *  App based on TrinteJS MVC framework
 *  TrinteJS homepage http://www.trintejs.com
 **/
 
var config = require('./configuration');

module.exports = function (app,express) {
    app.configure(function () {
        app.use(express.session({
            cookie: {
                maxAge: config.session.maxAge
            },
            key: config.session.key,
            secret: config.session.secret
        //  store: new sessionStore({
        //     url : config.dburi()
        //  })
        }));
    });
}